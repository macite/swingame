﻿using System;
using System.Collections.Generic;
using Color = System.Drawing.Color;
using SwinGame;

namespace $rootnamespace$
{
    public class $safeitemname$
    {
    }
}
